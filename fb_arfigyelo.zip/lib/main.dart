
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService().init();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FB Árfigyelő',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController keyword1Controller = TextEditingController();
  final TextEditingController keyword2Controller = TextEditingController();
  final TextEditingController keyword3Controller = TextEditingController();
  final TextEditingController maxPriceController = TextEditingController();
  String refreshRate = '15 percenként';

  final List<String> refreshOptions = [
    '15 percenként',
    '30 percenként',
    '1 óránként',
    '3 óránként',
  ];

  Timer? _timer;

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _scheduleCheck() {
    _timer?.cancel();
    Duration interval;
    switch (refreshRate) {
      case '30 percenként':
        interval = Duration(minutes: 30);
        break;
      case '1 óránként':
        interval = Duration(hours: 1);
        break;
      case '3 óránként':
        interval = Duration(hours: 3);
        break;
      default:
        interval = Duration(minutes: 15);
    }

    _timer = Timer.periodic(interval, (Timer timer) {
      NotificationService().showNotification(
        title: 'FB Árfigyelő',
        body: 'Ideje megnézni a Marketplace-t!',
      );
    });
  }

  void _launchMarketplace() async {
    const url = 'https://www.facebook.com/marketplace';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Nem lehet megnyitni a Facebook Marketplace-t.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FB Árfigyelő'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              controller: keyword1Controller,
              decoration: InputDecoration(labelText: 'Kulcsszó 1'),
            ),
            TextField(
              controller: keyword2Controller,
              decoration: InputDecoration(labelText: 'Kulcsszó 2'),
            ),
            TextField(
              controller: keyword3Controller,
              decoration: InputDecoration(labelText: 'Kulcsszó 3'),
            ),
            TextField(
              controller: maxPriceController,
              decoration: InputDecoration(labelText: 'Max ár (Ft)'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16),
            DropdownButton<String>(
              value: refreshRate,
              onChanged: (newValue) {
                setState(() {
                  refreshRate = newValue!;
                  _scheduleCheck();
                });
              },
              items: refreshOptions.map((rate) {
                return DropdownMenuItem(
                  value: rate,
                  child: Text(rate),
                );
              }).toList(),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                _scheduleCheck();
                _launchMarketplace();
              },
              child: Text('Marketplace megnyitása és figyelés indítása'),
            ),
          ],
        ),
      ),
    );
  }
}

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);

    await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  Future<void> showNotification({required String title, required String body}) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'marketplace_channel',
      'Marketplace Figyelő',
      channelDescription: 'Értesítések a Facebook Marketplace figyeléséről',
      importance: Importance.max,
      priority: Priority.high,
    );

    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);

    await flutterLocalNotificationsPlugin.show(
      0,
      title,
      body,
      platformChannelSpecifics,
    );
  }
}
